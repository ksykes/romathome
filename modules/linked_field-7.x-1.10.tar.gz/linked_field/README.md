CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation


INTRODUCTION
------------

Current Maintainers:

* [yannickoo](http://drupal.org/user/531118)
* [Fabian Pintsch](http://drupal.org/user/1625944)

Linked Field allows you to link fields to a specific destination.


INSTALLATION
------------

1. Install the module the drupal way [1]

2. Go to "Manage display" and click the settings button.
   Then you can just tick the "Link this field" checkbox
   and you will see a destination field and the token list.
   Select a token and click "Update".

[1] http://drupal.org/documentation/install/modules-themes/modules-7
